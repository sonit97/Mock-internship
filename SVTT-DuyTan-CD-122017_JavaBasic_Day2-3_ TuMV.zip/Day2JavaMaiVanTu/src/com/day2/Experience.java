package com.day2;

public class Experience extends Candidate{
	private int expInYear;
	private String proSkill;
	
	public Experience(){
		super();
	}
	public Experience(String candidateID, String fullName, String birthDay,
			String phone, String email, String candidateType,
			int candidateCount, int expInYear, String proSkill) {
		super(candidateID, fullName, birthDay, phone, email, candidateType,
				candidateCount);
		this.expInYear = expInYear;
		this.proSkill = proSkill;
	}
	public void showMe(){
		super.showInfo();
		System.out.printf("%-15s %-15s \n",expInYear,proSkill);
		//System.out.println("proSkill: "+ proSkill);
	}
	public int getExpInYear() {
		return expInYear;
	}
	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}
	public String getProSkill() {
		return proSkill;
	}
	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}
	
	
}
