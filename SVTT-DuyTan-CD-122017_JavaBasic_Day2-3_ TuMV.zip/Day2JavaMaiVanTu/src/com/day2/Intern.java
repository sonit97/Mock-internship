package com.day2;

public class Intern extends Candidate{
	private String majors;
	private String semester;
	private String university_name;	
	
	
	
	public Intern() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Intern(String candidateID, String fullName, String birthDay,
			String phone, String email, String candidateType, int candidateCount
			, String majors, String semester, String university_name
	) {
		super(candidateID, fullName, birthDay, phone, email, candidateType,
				candidateCount);
		this.majors = majors;
		this.semester = semester;
		this.university_name = university_name;
		// TODO Auto-generated constructor stub
	}


	public void showMe(){
		super.showInfo();
//		System.out.println("majors: "+majors);
//		System.out.println("semester: "+semester);
//		System.out.println("university_name: "+university_name);
		System.out.printf("%-15s %-15s %-15s \n",majors,semester,university_name);
	}
	
	
	public String getMajors() {
		return majors;
	}
	public void setMajors(String majors) {
		this.majors = majors;
	}
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getUniversity_name() {
		return university_name;
	}
	public void setUniversity_name(String universityName) {
		university_name = universityName;
	}
	
	
}
