package com.day2;

import java.util.ArrayList;


public class ManageCandidate {
	public static void main(String[] args) {
		 
		ArrayList<Candidate> listcan = new ArrayList<Candidate>();		
		
		Experience e1 = new Experience("CanID1","Mai Van Tu","30/03/1989","0982192919","tu@gmail.com","2",1,3,"Java");
		
		Experience e2 = new Experience("CanID4","Trung DepTrai","30/03/1989","0982192919","tu@gmail.com","2",1,3,"Java");
		
		Experience e3 = new Experience("CanID6","Ty DepTrai","30/03/1989","0982192919","tu@gmail.com","2",1,3,"Java");
				
		Fresher f1 = new Fresher("CanID2","Hong Duong","12/03/1921","0921924121","duong@gmail.com","0",1,"20/01/2017","Gioi","Dai Hoc Su Pham Ki Thuat");
		
		Intern i1 = new Intern("CanID3","Khanh Nhi","20/01/1996","0928192192","nhi@gmail.com","2",1,"IT","5","Dai Hoc Su Pham Ki Thuat");
		
		listcan.add(e1);
		listcan.add(f1);
		listcan.add(i1);
		listcan.add(e2);
		listcan.add(e3);
//		for (int i = 0; i < listcan.size(); i++) {
//			System.out.println("Info of candidates:---------------------- "+i);
//			listcan.get(i).showInfo();
//		}
		//System.out.printf("%-15s %-15s %-15s %-15s %-15s %-10s %-10s  %-15s %-15s", "candidateID", "fullName","birthDay","phone","email","candidate_type","candidate_count","expInYear","proSkill");
		for(Candidate ele : listcan){
			if(ele instanceof Experience){
				((Experience) ele).showMe();
			}
			// 
			
			if(ele instanceof Fresher){
				((Fresher) ele).showMe();
			}
			if(ele instanceof Intern){
				((Intern) ele).showMe();
			}
			
		}
		
		
	}
}
