package com.day2;

public class Fresher extends Candidate{
	private String graduation_date;
	private String graduation_rank;
	private String education;
	
	
		

	

	

	
	public Fresher() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Fresher(String candidateID, String fullName, String birthDay,
			String phone, String email, String candidateType, int candidateCount
			, String graduation_date, String graduation_rank, String education
	) {
		super(candidateID, fullName, birthDay, phone, email, candidateType,
				candidateCount);
		this.graduation_date = graduation_date;
		this.graduation_rank = graduation_rank;
		this.education = education;
		// TODO Auto-generated constructor stub
	}

	public void showMe(){
		super.showInfo();
//		System.out.println("graduation_date: "+graduation_date);
//		System.out.println("graduation_rank: "+graduation_rank);
//		System.out.println("education: "+education);
		System.out.printf("%-15s %-15s %-15s \n",graduation_date,graduation_rank,education);
	}
	
	public String getGraduation_date() {
		return graduation_date;
	}
	public void setGraduation_date(String graduationDate) {
		graduation_date = graduationDate;
	}
	public String getGraduation_rank() {
		return graduation_rank;
	}
	public void setGraduation_rank(String graduationRank) {
		graduation_rank = graduationRank;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	
	
}
