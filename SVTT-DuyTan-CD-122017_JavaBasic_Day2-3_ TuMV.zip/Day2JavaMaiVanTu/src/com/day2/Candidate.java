package com.day2;

import java.util.ArrayList;

public abstract class Candidate {
	
	private String candidateID;
	private String fullName;
	private String birthDay;
	private String phone;
	private String email;
	private String candidate_type; // 0: Experience, 1: Fresher, 2: Intern
	private int candidate_count;
	public ArrayList<Certificated> listCertificated;
	/**
	 * @param candidateID
	 * @param fullName
	 * @param birthDay
	 * @param phone
	 * @param email
	 * @param candidateType
	 * @param candidateCount
	 * @param listCertificated
	 */
	public Candidate(String candidateID, String fullName, String birthDay,
			String phone, String email, String candidateType,
			int candidateCount, ArrayList<Certificated> listCertificated) {
		super();
		this.candidateID = candidateID;
		this.fullName = fullName;
		this.birthDay = birthDay;
		this.phone = phone;
		this.email = email;
		candidate_type = candidateType;
		candidate_count = candidateCount;
		this.listCertificated = listCertificated;
	}
	
	
		
	
	public Candidate(){
		candidate_count++;
	}
	
	public void addCertificated(Certificated ce){
		listCertificated.add(ce);
	}
	
	public ArrayList<Certificated> getListCertificated() {
		return listCertificated;
	}



	public void setListCertificated(ArrayList<Certificated> listCertificated) {
		this.listCertificated = listCertificated;
	}



	public void showInfo(){
//		System.out.println("CandidateID: "+candidateID);
//		System.out.println("fullName: "+fullName);
//		System.out.println("birthDay: "+birthDay);
//		System.out.println("phone: "+phone);
//		System.out.println("email: "+email);
//		System.out.println("candidate_type: "+candidate_type);
//		System.out.println("candidate_count: "+candidate_count);
		System.out.printf("%-15s %-15s %-15s %-15s %-15s %-10s %-10s ", candidateID, fullName,birthDay,phone,email,candidate_type,candidate_count);
	}

	public Candidate(String candidateID, String fullName, String birthDay,
			String phone, String email, String candidateType,
			int candidateCount) {
		super();
		this.candidateID = candidateID;
		this.fullName = fullName;
		this.birthDay = birthDay;
		this.phone = phone;
		this.email = email;
		candidate_type = candidateType;
		candidate_count = candidateCount;
	}

	public String getCandidateID() {
		return candidateID;
	}

	public void setCandidateID(String candidateID) {
		this.candidateID = candidateID;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getBirthDay() {
		return birthDay;
	}

	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCandidate_type() {
		return candidate_type;
	}

	public void setCandidate_type(String candidateType) {
		candidate_type = candidateType;
	}

	public int getCandidate_count() {
		return candidate_count;
	}

	public void setCandidate_count(int candidateCount) {
		candidate_count = candidateCount;
	}
	
}
